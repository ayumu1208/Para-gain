package jp.co.handinhand.paragain.ui.notifications;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import jp.co.handinhand.paragain.R;

public class SingUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sing_up);
    }
}